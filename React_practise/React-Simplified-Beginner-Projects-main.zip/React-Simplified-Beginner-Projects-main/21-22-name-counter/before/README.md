# Before Getting Started

There is no starting code for this project since the styling/HTML are not important. You can use whatever HTML you want.

# Instructions

1. Create a new function component that has state for name and age
2. Create a text input that when updated will update the name state
3. Create a plus and minus button that will update the age state and display the state between the two buttons
4. Display the string `My name is {name} and I am {age} years old` in your JSX
5. Repeat but for a class component instead of a function component