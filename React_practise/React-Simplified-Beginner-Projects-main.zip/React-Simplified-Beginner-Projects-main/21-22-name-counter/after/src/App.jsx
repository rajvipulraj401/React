import { ClassComponent } from "./ClassComponent"

function App() {
  return <ClassComponent />
}

export default App
