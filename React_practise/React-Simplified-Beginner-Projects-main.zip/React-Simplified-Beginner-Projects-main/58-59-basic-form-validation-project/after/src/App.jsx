import { StateForm } from "./StateForm"
import "./styles.css"

export default function App() {
  return <StateForm />
}
