export function User({ name }) {
  return <li>{name}</li>
}
